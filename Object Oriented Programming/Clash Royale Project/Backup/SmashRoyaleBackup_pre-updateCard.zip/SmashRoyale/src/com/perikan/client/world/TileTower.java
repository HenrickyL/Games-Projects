package com.perikan.client.world;

import java.awt.image.BufferedImage;

public class TileTower extends Tile{ //separados para detectar colisão

	public TileTower(double x, double y, BufferedImage sprite) {
		super(x, y, sprite);
		
	}

}
