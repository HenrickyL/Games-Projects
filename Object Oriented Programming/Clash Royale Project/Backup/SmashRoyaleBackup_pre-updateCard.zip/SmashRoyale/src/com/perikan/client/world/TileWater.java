package com.perikan.client.world;

import java.awt.image.BufferedImage;

public class TileWater extends Tile{ //separados para detectar colisão

	public TileWater(int x, int y, BufferedImage sprite) {
		super(x, y, sprite);
		
	}

}
