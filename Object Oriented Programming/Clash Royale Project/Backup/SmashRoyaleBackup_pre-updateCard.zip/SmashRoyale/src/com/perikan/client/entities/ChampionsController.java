package com.perikan.client.entities;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

import com.perikan.client.config.MatchController;
import com.perikan.client.main.Game;
import com.perikan.client.world.Tile;

public class ChampionsController extends Entity{
	private int u = Tile.En_W_H;
	private boolean isPressed = false;
	private double xTarget,yTarget;
	private boolean canSummor = true;
	private boolean invalidPosition = false;
	
	
	public ChampionsController(double x, double y, int width, int heigth, BufferedImage sprite) {
		super(x, y, width, heigth, sprite);
		// TODO Auto-generated constructor stub
		
		
		
	}
	@Override
	public void tick(Player p) {
		invalidPosition = false;
		if(isPressed && (yTarget>4.5*u &&  yTarget<7.5*u)) {
			
			System.out.println("add");
			isPressed = false;
			//criar um champion no local
			double xx = xTarget*(Game.getSCALE())-u/2;
			double yy = yTarget*(Game.getSCALE())-u/2;
			Champion champ;// = new Champion(xx,yy, u,u);
			if(champ.cost >p.getElixir() ) {
				canSummor = false; //não pode invocar
				System.out.println("Não pode invocar!");
				champ.setDestroyed(true);
			}else {
				Game.match.getEntities().add(champ);
				Game.match.champEnemy.add(champ);
				p.getChampions().add(champ);
				//champ.towerFocus(Game.match.getTowerEnemy());
				canSummor = true;
				p.setElixir((p.getElixir()- champ.cost));
			}
			
		}
		else if(isPressed && (yTarget<4.5*u || yTarget> 7.5*u)){
			invalidPosition = true;
			isPressed = false;
			
		}
		//se destruido
		if(this.isDestroyed) {
			Game.match.getEntities().remove(this);
		}
		
	}
	
	
	
	
	
	//Getter e setter
	public boolean getPressed() {
		return isPressed;
	}
	public void setPressed(boolean isPressed) {
		this.isPressed = isPressed;
	}
	public double getxTarget() {
		return xTarget;
	}
	public void setxTarget(double xTarget) {
		this.xTarget = xTarget;
	}
	public double getyTarget() {
		return yTarget;
	}
	public void setyTarget(double yTarget) {
		this.yTarget = yTarget;
	}
	public boolean isInvalidPosition() {
		return invalidPosition;
	}
	public void setInvalidPosition(boolean invalidPosition) {
		this.invalidPosition = invalidPosition;
	}
	public boolean isPressed() {
		return isPressed;
	}
	

	
	
	
}
