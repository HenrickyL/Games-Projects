package com.perikan.client.entities.champs;

import java.awt.Graphics;

import com.perikan.client.entities.Champion;

public class Giant extends Champion{

	public Giant(double x, double y, int width, int heigth) {
		super(x, y, width, heigth);
		this.cost = 5; 
	}
	@Override
	public void tick() {
		super.tick();
	}
	@Override
	public void render(Graphics g) {
		super.render(g);
	}
}
