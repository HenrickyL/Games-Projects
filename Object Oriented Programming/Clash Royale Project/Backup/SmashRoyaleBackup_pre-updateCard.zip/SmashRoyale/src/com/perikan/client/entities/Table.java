package com.perikan.client.entities;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import com.perikan.client.world.Tile;

public class Table extends Entity {

	public Table(double x, double y, int width, int heigth, BufferedImage sprite) {
		super(x, y, width, heigth, sprite);
		// TODO Auto-generated constructor stub
		
	}

}
