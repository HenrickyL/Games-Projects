package com.perikan.server.entities;

import java.awt.image.BufferedImage;

public class Card extends Entity{
	
	public Card(double x, double y, int width, int heigth, BufferedImage sprite) {
		super(x, y, width, heigth, sprite);
		// TODO Auto-generated constructor stub
	}
}
