package com.perikan.server.world;

import java.awt.image.BufferedImage;

public class TileStreet extends Tile{ //separados para detectar colisão

	public TileStreet(double x, double y, BufferedImage sprite) {
		super(x, y, sprite);
		
	}

}
