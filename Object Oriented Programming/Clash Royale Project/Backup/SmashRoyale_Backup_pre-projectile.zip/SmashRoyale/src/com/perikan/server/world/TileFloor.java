package com.perikan.server.world;

import java.awt.image.BufferedImage;

public class TileFloor extends Tile{ //separados para detectar colisão

	public TileFloor(int x, int y, BufferedImage sprite) {
		super(x, y, sprite);
		
	}

}
