package com.perikan.server.entities;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import com.perikan.server.world.Tile;

public class Tower extends Entity{
	protected int maskX=Tile.En_W_H,
			maskY=Tile.En_W_H,
			maskW=Tile.En_W_H,
			maskH = Tile.En_W_H;
	protected boolean isRed;
	protected Color cor;
		//construtor
		public Tower(int x, int y, int width, int heigth, BufferedImage sprite,boolean isRed) {
			super(x, y, width, heigth, sprite);
			this.isRed = isRed;
			// TODO Auto-generated constructor stub
			isDestroyed = false;
		}
		public int getMaskX() {
			return maskX;
		}
		public void setMaskX(int maskX) {
			this.maskX = maskX;
		}
		public int getMaskY() {
			return maskY;
		}
		public void setMaskY(int maskY) {
			this.maskY = maskY;
		}
	
		
	}


