package com.perikan.server.graphic;

import java.awt.Color;
import java.awt.Graphics;

import com.perikan.server.main.*;


public class UI {
	public void render(Graphics g) {
		//g.setColor(Color.red);
		//g.fillRect(Game.player.getX()-1,Game.player.getY()-3,16,1);
		//g.setColor(Color.green);
		//g.fillRect(Game.player.getX()-1,Game.player.getY()-3,(int)((Game.player.Hp/Game.player.HpMax)*16),1);
		
	}
}
