package com.perikan.server.entities;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

import com.perikan.server.main.Game;

public class Player extends Entity{
	//server options
	private String userName;
	
	
	private int elixir=0;
	private int crown=0;
	//guardar relacionados ao jogador
	private List<Card> deck; //guarda as cartas
	private List<Tower> towers; //guardar as 3 torres
	private Tower tKing,tArcLeft,tArcRigth;
	private List<Entity> entities; // guardar todas as entidades;
	private List<Champion> champions;//guardar os campeões
	//Construtor
	public Player(double x, double y, int width, int heigth, BufferedImage sprite,
			String userName) {
		super(x, y, width, heigth, sprite);
		//username
		this.userName = userName;
		
		this.elixir = 3;
		this.champions = new ArrayList<Champion>();
		try {
			towers = Game.match.getTowerAlly();
			for(Tower t: towers) {
				if(t instanceof TowerKing) {
					tKing = t;
				}else if(t != tArcLeft){
					tArcLeft = t;
				}else tArcRigth= t;
			}
			if(tArcLeft.getX() > tArcRigth.getX()) {
				Tower aux = tArcLeft;
				tArcLeft = tArcRigth;
				tArcRigth = aux;
			}
			} catch (Exception e) {
				//ainda não faz nada
			}
		
	}
	//Metodos
	public void tick() {
		//se uma das arqueiras cair o rei pode ser atacado
		if(tArcLeft.isDestroyed() == true && tArcRigth.isDestroyed() == true) {
			tKing.setDestroyed(true);
		}
	}
	
	
	
	
	//				::::  GETTER E SETTER
	public int getElixir() {
		return elixir;
	}
	public void setElixir(int elixir) {
		this.elixir = elixir;
	}
	public List<Tower> getTowers() {
		return towers;
	}
	public void setTowers(List<Tower> towers) {
		this.towers = towers;
	}
	public int getCrown() {
		return crown;
	}
	public void setCrown(int crown) {
		this.crown = crown;
	}
	public List<Champion> getChampions() {
		return champions;
	}
	public void setChampions(List<Champion> champions) {
		this.champions = champions;
	}
	
	
	
	
}
